<?php
$title = "Manage Materi Pelajaran";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageMateri.php';
include VIEW . 'index.php';
