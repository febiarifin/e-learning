<?php
$title = "Buat Materi Pelajaran";
$main = VIEW . 'home.php';
$submain = VIEW . 'materiPelajaran.php';
include VIEW . 'index.php';
