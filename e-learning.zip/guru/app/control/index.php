<?php
$title = "Dashboard-Guru";
$main = VIEW . 'home.php';
$submain = VIEW . 'dashboard.php';
include VIEW . 'index.php';
