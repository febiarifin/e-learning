<?php

include "config/url.php";

require 'config/conn.php';
require 'config/config.php';
require 'config/route.php';
