<?php
$title = "E-Learning SMK Maju Jaya";
include VIEW . 'index.php';