<?php
$title = "Manage Guru";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageGuru.php';
include VIEW . 'index.php';
