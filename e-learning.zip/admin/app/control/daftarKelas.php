<?php
$title = "Daftar Kelas";
$main = VIEW . 'home.php';
$submain = VIEW . 'daftarKelas.php';
include VIEW . 'index.php';
