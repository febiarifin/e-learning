<?php
$title = "Daftar Mapel";
$main = VIEW . 'home.php';
$submain = VIEW . 'daftarMapel.php';
include VIEW . 'index.php';
