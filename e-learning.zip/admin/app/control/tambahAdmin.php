<?php
$title = "Tambah Admin";
$main = VIEW . 'home.php';
$submain = VIEW . 'tambahAdmin.php';
include VIEW . 'index.php';
