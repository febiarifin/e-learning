<?php
$title = "Log activity";
$main = VIEW . 'home.php';
$submain = VIEW . 'log.php';
include VIEW . 'index.php';
