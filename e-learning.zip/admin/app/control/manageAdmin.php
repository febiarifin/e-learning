<?php
$title = "Manage Admin";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageAdmin.php';
include VIEW . 'index.php';
