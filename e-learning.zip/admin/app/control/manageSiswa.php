<?php
$title = "Manage Siswa";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageSiswa.php';
include VIEW . 'index.php';
