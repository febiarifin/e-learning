<?php
$title = "Dashboard-Admin";
$main = VIEW . 'home.php';
$submain = VIEW . 'dashboard.php';
include VIEW . 'index.php';
