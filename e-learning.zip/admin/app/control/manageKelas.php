<?php
$title = "Manage Kelas";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageKelas.php';
include VIEW . 'index.php';
