<?php
$title = "Buat Kelas Siswa";
$main = VIEW . 'home.php';
$submain = VIEW . 'buatKelas.php';
include VIEW . 'index.php';
