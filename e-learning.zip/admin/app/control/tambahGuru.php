<?php
$title = "Tambah Guru";
$main = VIEW . 'home.php';
$submain = VIEW . 'tambahGuru.php';
include VIEW . 'index.php';
