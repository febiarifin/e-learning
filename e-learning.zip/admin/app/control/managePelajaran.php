<?php
$title = "Manage Pelajaran";
$main = VIEW . 'home.php';
$submain = VIEW . 'managePelajaran.php';
include VIEW . 'index.php';
