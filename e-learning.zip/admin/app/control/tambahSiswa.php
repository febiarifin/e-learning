<?php
$title = "Tambah Siswa";
$main = VIEW . 'home.php';
$submain = VIEW . 'tambahSiswa.php';
include VIEW . 'index.php';
