<?php
$title = "Edit Profil";
$main = VIEW . 'home.php';
$submain = VIEW . 'editProfil.php';
include VIEW . 'index.php';
