<?php
$title = "Buat Mapel Kelas";
$main = VIEW . 'home.php';
$submain = VIEW . 'buatMapel.php';
include VIEW . 'index.php';
