<div class="card col-md-12">
    <img src="asset/img/bg.png" class="card-img-top" alt="Background">
    <div class="card-body">
        <h1 class="font-weight-normal">Selamat datang admin <b><?= $username ?> .</b></h1>
    </div>
    <div class="card-footer">
        <h4>Faker generator untuk insert data guru dan siswa.</h4>
        <hr>
        <a href="?m=fakerSiswa" class="btn btn-primary col-md-12 mb-3">Tambah data siswa 30</a>
        <a href="?m=fakerGuru" class="btn btn-primary col-md-12">Tambah data guru 5</a>
    </div>
</div>