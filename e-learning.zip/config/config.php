<?php
define("CONTROL", "app/control/");
define("VIEW", "app/view/");
define("ICON", "asset/icon/");