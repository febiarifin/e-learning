<?php

include "config/url.php";

require $url . 'config/conn.php';
require 'config/config.php';
require 'config/route.php';
