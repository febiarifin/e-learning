<?php
define("CONTROL", "app/control/");
define("VIEW", "app/view/");
define("MODEL", "app/model/");
define("ICON", $url."asset/icon/");
