<?php
$title = "Edit Foto Profil";
$main = VIEW . 'home.php';
$submain = VIEW . 'editProfil.php';
include VIEW . 'index.php';
