<?php
$title = "Dashboard-Siswa";
$main = VIEW . 'home.php';
$submain = VIEW . 'dashboard.php';
include VIEW . 'index.php';
