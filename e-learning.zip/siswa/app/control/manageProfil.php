<?php
$title = "Manage Profil";
$main = VIEW . 'home.php';
$submain = VIEW . 'manageProfil.php';
include VIEW . 'index.php';
