<?php
$title = "Pelajaran";
$main = VIEW . 'home.php';
$submain = VIEW . 'pelajaran.php';
include VIEW . 'index.php';
