<div class="card col-md-12">
    <img src="asset/img/bg.png" class="card-img-top" alt="Background">
    <div class="card-body">
        <h1 class="font-weight-normal">Selamat datang <b><?= $nama ?> .</b></h1>
    </div>
</div>